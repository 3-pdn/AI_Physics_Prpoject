
# ==========================================================
# Project: AI Learns Physical Laws from Simulation
# System: Free-Fall Motion
# Method: Symbolic Regression
# ==========================================================

import numpy as np
import matplotlib.pyplot as plt
from gplearn.genetic import SymbolicRegressor

np.random.seed(0)

t = np.linspace(0, 5, 100).reshape(-1, 1)

x0 = 10.0
v0 = 0.0
g = -9.8

x = x0 + v0 * t.flatten() + 0.5 * g * t.flatten()**2
noise = np.random.normal(0, 0.1, size=len(x))
x_noisy = x + noise

model = SymbolicRegressor(
    population_size=3000,
    generations=20,
    function_set=['add', 'sub', 'mul'],
    parsimony_coefficient=0.01,
    max_samples=0.9,
    verbose=1,
    random_state=0
)

model.fit(t, x_noisy)

print("\n===================================")
print("AI Discovered Physical Law:")
print(model._program)
print("===================================\n")

x_ai = model.predict(t)

plt.figure(figsize=(8, 5))
plt.scatter(t, x_noisy, label="Simulated Data (Noisy)", s=20)
plt.plot(t, x_ai, label="AI Discovered Law", linewidth=2)
plt.xlabel("Time (t)")
plt.ylabel("Position (x)")
plt.title("AI Learning Physical Law from Data")
plt.legend()
plt.grid(True)
plt.show()

print("Conclusion: AI rediscovered a quadratic motion law.")
