
AI Physics Symbolic Regression Project

Run Steps:
1. pip install -r requirements.txt
2. python physics_symbolic_regression.py
